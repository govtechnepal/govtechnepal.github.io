import {
  mountChromeApp
} from "./chunks/chunk-5SQ6C2LE.js";
import "./chunks/chunk-EZEORY6B.js";

// apps/chrome/src/popup.ts
var root = document.getElementById("app");
if (root) void mountChromeApp(root, "popup");
