"use strict";
(() => {
  // packages/engine/src/types.ts
  var DEFAULT_LIPI_CONFIG = {
    layout: "romanized",
    suggestCorrections: false,
    firstRunComplete: false,
    userWords: [],
    ignoredWords: []
  };

  // data/layouts/romanized.json
  var romanized_default = {
    id: "romanized",
    name: "Romanized",
    nameNe: "\u0930\u094B\u092E\u0928\u093E\u0907\u091C\u094D\u0921",
    version: "1.0.1",
    attribution: "Madan Puraskar Pratisthan / Language Technology Kendra. Machine-readable mappings derived from the Keyman encoding by Santosh Pradhan (MIT), nepali_romanized v1.0.1.",
    mappings: {
      "`": "\u093C",
      "~": "\u093D",
      "1": "\u0967",
      "!": "!",
      "2": "\u0968",
      "@": "@",
      "3": "\u0969",
      "#": "#",
      "4": "\u096A",
      $: "$",
      "5": "\u096B",
      "%": "%",
      "6": "\u096C",
      "^": "^",
      "7": "\u096D",
      "&": "&",
      "8": "\u096E",
      "*": "*",
      "9": "\u096F",
      "(": "(",
      "0": "\u0966",
      ")": ")",
      "-": "-",
      _: "_",
      "=": "\u200D",
      "+": "\u200C",
      q: "\u091F",
      Q: "\u0920",
      w: "\u094C",
      W: "\u0914",
      e: "\u0947",
      E: "\u0948",
      r: "\u0930",
      R: "\u0943",
      t: "\u0924",
      T: "\u0925",
      y: "\u092F",
      Y: "\u091E",
      u: "\u0941",
      U: "\u0942",
      i: "\u093F",
      I: "\u0940",
      o: "\u094B",
      O: "\u0913",
      p: "\u092A",
      P: "\u092B",
      "[": "\u0907",
      "{": "\u0908",
      "]": "\u090F",
      "}": "\u0910",
      "\\": "\u0950",
      "|": "\u0903",
      a: "\u093E",
      A: "\u0906",
      s: "\u0938",
      S: "\u0936",
      d: "\u0926",
      D: "\u0927",
      f: "\u0909",
      F: "\u090A",
      g: "\u0917",
      G: "\u0918",
      h: "\u0939",
      H: "\u0905",
      j: "\u091C",
      J: "\u091D",
      k: "\u0915",
      K: "\u0916",
      l: "\u0932",
      L: "\u0965",
      ";": ";",
      ":": ":",
      "'": "'",
      '"': '"',
      z: "\u0937",
      Z: "\u090B",
      x: "\u0921",
      X: "\u0922",
      c: "\u091A",
      C: "\u091B",
      v: "\u0935",
      V: "\u0901",
      b: "\u092C",
      B: "\u092D",
      n: "\u0928",
      N: "\u0923",
      m: "\u092E",
      M: "\u0902",
      ",": ",",
      "<": "\u0919",
      ".": "\u0964",
      ">": ".",
      "/": "\u094D",
      "?": "?"
    },
    deadKeys: {}
  };

  // data/layouts/traditional.json
  var traditional_default = {
    id: "traditional",
    name: "Traditional",
    nameNe: "\u092A\u0930\u092E\u094D\u092A\u0930\u093E\u0917\u0924",
    version: "1.3.1",
    attribution: "Madan Puraskar Pratisthan / Language Technology Kendra. Machine-readable mappings derived from the Keyman encoding by Santosh Pradhan (MIT), nepali_traditional v1.3.1. Dead key { for ASCII punctuation is from that encoding.",
    mappings: {
      "`": "\u091E",
      "~": "\u093D",
      "1": "\u0967",
      "!": "\u091C\u094D\u091E",
      "2": "\u0968",
      "@": "\u0908",
      "3": "\u0969",
      "#": "\u0918",
      "4": "\u096A",
      $: "\u0926\u094D\u0927",
      "5": "\u096B",
      "%": "\u091B",
      "6": "\u096C",
      "^": "\u091F",
      "7": "\u096D",
      "&": "\u0920",
      "8": "\u096E",
      "*": "\u0921",
      "9": "\u096F",
      "(": "\u0922",
      "0": "\u0966",
      ")": "\u0923",
      "-": "\u0914",
      _: "\u0913",
      "=": ".",
      "+": "\u0902",
      q: "\u0924\u094D\u0930",
      Q: "\u0924\u094D\u0924",
      w: "\u0927",
      W: "\u0927\u094D",
      e: "\u092D",
      E: "\u0910",
      r: "\u091A",
      R: "\u091A\u094D",
      t: "\u0924",
      T: "\u0924\u094D",
      y: "\u0925",
      Y: "\u0925\u094D",
      u: "\u0917",
      U: "\u090A",
      i: "\u0937",
      I: "\u0915\u094D\u0937",
      o: "\u092F",
      O: "\u0907",
      p: "\u0909",
      P: "\u090F",
      "[": "\u0943",
      "]": "\u0947",
      "}": "\u0948",
      "\\": "\u094D",
      "|": "\u200D",
      a: "\u092C",
      A: "\u0906",
      s: "\u0915",
      S: "\u0915\u094D",
      d: "\u092E",
      D: "\u092E\u094D",
      f: "\u093E",
      F: "\u0901",
      g: "\u0928",
      G: "\u0928\u094D",
      h: "\u091C",
      H: "\u091D",
      j: "\u0935",
      J: "\u094B",
      k: "\u092A",
      K: "\u092B",
      l: "\u093F",
      L: "\u0940",
      ";": "\u0938",
      ":": "\u0938\u094D",
      "'": "\u0941",
      '"': "\u0942",
      z: "\u0936",
      Z: "\u0936\u094D",
      x: "\u0939",
      X: "\u0939\u094D",
      c: "\u0905",
      C: "\u090B",
      v: "\u0916",
      V: "\u0950",
      b: "\u0926",
      B: "\u094C",
      n: "\u0932",
      N: "\u0932\u094D",
      m: "\u200C",
      M: "\u0903",
      ",": ",",
      "<": "\u0919",
      ".": "\u0964",
      ">": "\u0936\u094D\u0930",
      "/": "\u0930",
      "?": "?"
    },
    deadKeys: {
      "{": {
        "`": "`",
        "~": "~",
        "!": "!",
        "@": "@",
        "#": "#",
        $: "$",
        "%": "%",
        "^": "^",
        "&": "&",
        "*": "*",
        "(": "(",
        ")": ")",
        "1": "!",
        "2": "@",
        "3": "#",
        "4": "$",
        "5": "%",
        "6": "^",
        "7": "&",
        "8": "*",
        "9": "(",
        "0": ")",
        "-": "-",
        _: "_",
        "=": "=",
        "+": "+",
        "[": "[",
        "{": "{",
        "]": "]",
        "}": "}",
        "\\": "\\",
        "|": "|",
        ";": ";",
        ":": ":",
        "'": "'",
        '"': '"',
        "<": "<",
        ".": ".",
        ",": ",",
        ">": ">",
        "/": "/",
        "?": "\u0931\u094D"
      }
    }
  };

  // packages/engine/src/layouts.ts
  var ROMANIZED = romanized_default;
  var TRADITIONAL = traditional_default;
  var LAYOUTS = {
    romanized: ROMANIZED,
    traditional: TRADITIONAL
  };
  function lookupLayout(id, key) {
    return LAYOUTS[id].mappings[key];
  }
  function lookupDeadKey(id, dead, key) {
    return LAYOUTS[id].deadKeys[dead]?.[key];
  }
  function isDeadKeyTrigger(id, key) {
    return Boolean(LAYOUTS[id].deadKeys[key]);
  }

  // packages/engine/src/backspace.ts
  function isDevanagariCombiningMark(codePoint) {
    return codePoint >= 2304 && codePoint <= 2307 || codePoint >= 2362 && codePoint <= 2381 || codePoint >= 2385 && codePoint <= 2391 || codePoint >= 2402 && codePoint <= 2403;
  }
  function deleteLastInputUnit(text) {
    if (!text) return "";
    const scalars = [...text];
    const last = scalars[scalars.length - 1];
    const cp = last.codePointAt(0);
    if (isDevanagariCombiningMark(cp)) {
      scalars.pop();
      return scalars.join("");
    }
    if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
      const segs = [...new Intl.Segmenter("ne", { granularity: "grapheme" }).segment(text)];
      segs.pop();
      return segs.map((part) => part.segment).join("");
    }
    scalars.pop();
    return scalars.join("");
  }

  // packages/engine/src/proofread.ts
  var WORD_CHAR = /[\u0900-\u0963\u0970-\u097F\u200C\u200D]/;
  function completedWordSpans(text) {
    const spans = [];
    let i = 0;
    while (i < text.length) {
      if (!WORD_CHAR.test(text[i])) {
        i += 1;
        continue;
      }
      const start = i;
      while (i < text.length && WORD_CHAR.test(text[i])) i += 1;
      const end = i;
      const next = text[end];
      if (next !== void 0 && !WORD_CHAR.test(next)) {
        spans.push({ word: text.slice(start, end), start, end });
      }
    }
    return spans;
  }

  // packages/engine/src/phonetic.ts
  var RULES = [
    ["chh", "C", ["\u091B"]],
    ["ksh", "C", ["\u0915\u094D\u0937"]],
    ["k\u1E63", "C", ["\u0915\u094D\u0937"]],
    ["gya", "C", ["\u091C\u094D\u091E"]],
    ["gya", "C", ["\u091C\u094D\u091E"]],
    ["shr", "C", ["\u0936\u094D\u0930"]],
    ["\u015Br", "C", ["\u0936\u094D\u0930"]],
    ["tr", "C", ["\u0924\u094D\u0930"]],
    ["ch", "C", ["\u091A", "\u091B"]],
    ["kh", "C", ["\u0916"]],
    ["gh", "C", ["\u0918"]],
    ["th", "C", ["\u0925", "\u0920"]],
    ["dh", "C", ["\u0927", "\u0922"]],
    ["ph", "C", ["\u092B"]],
    ["bh", "C", ["\u092D"]],
    ["sh", "C", ["\u0936", "\u0937"]],
    ["ng", "C", ["\u0919", "\u0919\u094D\u0917"]],
    ["ny", "C", ["\u091E"]],
    ["jh", "C", ["\u091D"]],
    ["gy", "C", ["\u091C\u094D\u091E", "\u0917\u094D\u092F"]],
    ["jn", "C", ["\u091C\u094D\u091E"]],
    ["aa", "V", ["\u093E", "\u0906"]],
    ["a:", "V", ["\u093E", "\u0906"]],
    ["ai", "V", ["\u0948", "\u0910"]],
    ["au", "V", ["\u094C", "\u0914"]],
    ["ou", "V", ["\u094C", "\u0914"]],
    ["ee", "V", ["\u0940", "\u0908"]],
    ["ii", "V", ["\u0940", "\u0908"]],
    ["oo", "V", ["\u0942", "\u090A"]],
    ["uu", "V", ["\u0942", "\u090A"]],
    ["ri", "V", ["\u0943", "\u090B"]],
    ["a", "V", ["*", "\u093E", "\u0906"]],
    ["i", "V", ["\u093F", "\u0940", "\u0907", "\u0908"]],
    ["u", "V", ["\u0941", "\u0942", "\u094C", "\u0909", "\u090A", "\u094C\u0902"]],
    ["e", "V", ["\u0947", "\u090F"]],
    ["o", "V", ["\u094B", "\u0913"]],
    ["k", "C", ["\u0915"]],
    ["g", "C", ["\u0917"]],
    ["c", "C", ["\u091A"]],
    ["j", "C", ["\u091C"]],
    ["t", "C", ["\u0924", "\u091F"]],
    ["d", "C", ["\u0926", "\u0921"]],
    ["n", "C", ["\u0928", "\u0923", "\u0902"]],
    ["p", "C", ["\u092A"]],
    ["b", "C", ["\u092C"]],
    ["m", "C", ["\u092E", "\u0902"]],
    ["y", "C", ["\u092F"]],
    ["r", "C", ["\u0930"]],
    ["l", "C", ["\u0932"]],
    ["v", "C", ["\u0935"]],
    ["w", "C", ["\u0935"]],
    ["s", "C", ["\u0938", "\u0936", "\u0937"]],
    ["h", "C", ["\u0939"]],
    ["f", "C", ["\u092B"]],
    ["q", "C", ["\u0915"]],
    ["x", "C", ["\u0915\u094D\u0937", "\u0915\u094D\u0938"]],
    ["z", "C", ["\u091C", "\u0937"]]
  ];
  RULES.sort((a, b) => b[0].length - a[0].length);

  // packages/engine/src/ime.ts
  var PASS_THROUGH = /* @__PURE__ */ new Set([
    "Tab",
    "Escape",
    "ArrowLeft",
    "ArrowRight",
    "ArrowUp",
    "ArrowDown",
    "Home",
    "End",
    "PageUp",
    "PageDown",
    "Delete",
    "Insert"
  ]);
  var WORD_RE = /[\u0900-\u0963\u0966-\u097F\u200c\u200d]/;
  function createState(mode = "romanized", settings) {
    return {
      mode,
      deadKey: null,
      currentWord: "",
      settings: { suggestCorrections: false, ...settings },
      lastCorrection: null,
      userWords: {},
      composing: "",
      romanBuffer: "",
      selectedIndex: 0,
      lastCommitted: "",
      userBigrams: {}
    };
  }
  function cloneState(s) {
    return {
      ...s,
      settings: { ...s.settings },
      lastCorrection: s.lastCorrection ? { ...s.lastCorrection } : null,
      userWords: { ...s.userWords },
      userBigrams: { ...s.userBigrams }
    };
  }
  function pack(state, extra = {}) {
    return {
      newState: state,
      committedText: extra.committedText ?? "",
      composingText: extra.composingText ?? "",
      candidates: extra.candidates ?? [],
      correction: extra.correction ?? null,
      consumed: extra.consumed ?? true,
      deleteBackward: extra.deleteBackward ?? false
    };
  }
  function maybeCorrect(state, dict) {
    if (!state.settings.suggestCorrections || !dict) return null;
    const word = state.currentWord;
    if (!word) return null;
    if (dict.isKnown(word)) return null;
    const hits = dict.corrections(word, 1);
    if (!hits[0] || hits[0] === word) return null;
    return { original: word, suggestion: hits[0] };
  }
  function appendWord(state, chunk) {
    for (const ch of chunk) {
      if (WORD_RE.test(ch)) state.currentWord += ch;
      else state.currentWord = "";
    }
  }
  function handleKey(state, event, dict) {
    const s = cloneState(state);
    s.lastCorrection = null;
    if (event.ctrlKey || event.metaKey || event.altKey) {
      return pack(s, { consumed: false });
    }
    const key = event.key;
    const isSpace = key === " " || key === "Space" || key === "Spacebar" || event.code === "Space";
    const isBackspace = key === "Backspace" || event.code === "Backspace";
    if (key === "Escape") {
      s.deadKey = null;
      s.romanBuffer = "";
      s.composing = "";
      return pack(s);
    }
    if (isBackspace) {
      if (s.deadKey) {
        s.deadKey = null;
        return pack(s);
      }
      if (s.mode === "smart" && s.romanBuffer) {
        s.romanBuffer = deleteLastInputUnit(s.romanBuffer);
        return pack(s, { composingText: s.romanBuffer });
      }
      if (s.currentWord) s.currentWord = deleteLastInputUnit(s.currentWord);
      return pack(s, { deleteBackward: true });
    }
    if (s.mode === "smart") {
      return handleSmart(s, key, dict);
    }
    const layoutId = s.mode;
    if (s.deadKey) {
      const mapped = lookupDeadKey(layoutId, s.deadKey, key);
      s.deadKey = null;
      if (mapped !== void 0) {
        appendWord(s, mapped);
        s.lastCommitted = mapped;
        return pack(s, { committedText: mapped });
      }
    }
    if (isDeadKeyTrigger(layoutId, key)) {
      s.deadKey = key;
      return pack(s);
    }
    if (key === "Enter") {
      const correction = maybeCorrect(s, dict);
      s.currentWord = "";
      s.lastCorrection = correction;
      return pack(s, {
        consumed: false,
        correction,
        candidates: correctionToCandidates(correction)
      });
    }
    if (isSpace) {
      const correction = maybeCorrect(s, dict);
      s.currentWord = "";
      s.lastCorrection = correction;
      s.lastCommitted = " ";
      return pack(s, {
        committedText: " ",
        correction,
        candidates: correctionToCandidates(correction)
      });
    }
    if (key.length === 1) {
      const mapped = lookupLayout(layoutId, key);
      if (mapped !== void 0) {
        appendWord(s, mapped);
        s.lastCommitted = mapped;
        return pack(s, { committedText: mapped });
      }
      const correction = maybeCorrect(s, dict);
      s.currentWord = "";
      s.lastCorrection = correction;
      return pack(s, {
        consumed: false,
        committedText: key,
        correction,
        candidates: correctionToCandidates(correction)
      });
    }
    if (PASS_THROUGH.has(key)) {
      return pack(s, { consumed: false });
    }
    return pack(s, { consumed: false });
  }
  function correctionToCandidates(c) {
    if (!c) return [];
    return [{ text: c.suggestion, kind: "correction", score: 1 }];
  }
  function handleSmart(s, key, _dict) {
    if (key.length === 1 && /[a-zA-Z]/.test(key)) {
      s.romanBuffer += key.toLowerCase();
      return pack(s, { composingText: s.romanBuffer });
    }
    if (key === " " || key === "Enter") {
      const text = s.romanBuffer;
      s.romanBuffer = "";
      return pack(s, { committedText: key === " " ? text + " " : text, composingText: "" });
    }
    return pack(s, { consumed: false, composingText: s.romanBuffer });
  }
  function setMode(state, mode) {
    const s = cloneState(state);
    s.mode = mode;
    s.deadKey = null;
    s.currentWord = "";
    s.romanBuffer = "";
    s.composing = "";
    s.selectedIndex = 0;
    s.lastCorrection = null;
    return s;
  }

  // packages/engine/src/config.ts
  function stringList(value) {
    if (!Array.isArray(value)) return [];
    const out = [];
    for (const item of value) {
      if (typeof item === "string" && item.length > 0 && !out.includes(item)) out.push(item);
    }
    return out;
  }
  function parseLipiConfig(raw) {
    try {
      const j = JSON.parse(raw);
      return {
        layout: j.layout === "traditional" ? "traditional" : "romanized",
        suggestCorrections: Boolean(j.suggestCorrections),
        firstRunComplete: Boolean(j.firstRunComplete),
        userWords: stringList(j.userWords),
        ignoredWords: stringList(j.ignoredWords)
      };
    } catch {
      return { ...DEFAULT_LIPI_CONFIG };
    }
  }

  // apps/chrome/src/settings.ts
  var LS_KEY = "lipi-config";
  function chromeStorage() {
    const c = globalThis.chrome;
    const local = c?.storage?.local;
    if (!local || typeof local.get !== "function") return null;
    return local;
  }
  async function loadSettings() {
    const local = chromeStorage();
    if (local) {
      const all = await local.get(null);
      return parseLipiConfig(JSON.stringify(all ?? {}));
    }
    try {
      return parseLipiConfig(localStorage.getItem(LS_KEY) || "");
    } catch {
      return { ...DEFAULT_LIPI_CONFIG };
    }
  }
  function onSettingsChanged(cb) {
    const c = globalThis.chrome;
    c?.storage?.onChanged?.addListener(() => cb());
    window.addEventListener?.("storage", (ev) => {
      if (ev.key === LS_KEY) cb();
    });
  }

  // apps/chrome/src/content.ts
  var layout = "romanized";
  var proofread = false;
  var states = /* @__PURE__ */ new WeakMap();
  var unknown = /* @__PURE__ */ new Map();
  void loadSettings().then((cfg) => {
    layout = cfg.layout;
    proofread = cfg.suggestCorrections;
  });
  onSettingsChanged(() => {
    void loadSettings().then((cfg) => {
      layout = cfg.layout;
      proofread = cfg.suggestCorrections;
      if (!proofread) unknown.clear();
    });
  });
  function stateFor(el) {
    let s = states.get(el);
    if (!s) {
      s = createState(layout);
      states.set(el, s);
      return s;
    }
    if (s.mode !== layout) {
      s = setMode(s, layout);
      states.set(el, s);
    }
    return s;
  }
  function editable(target) {
    if (!(target instanceof HTMLElement)) return null;
    if (target.closest("[data-lipi-skip]")) return null;
    if (target instanceof HTMLInputElement) {
      const skip = /* @__PURE__ */ new Set([
        "password",
        "email",
        "number",
        "file",
        "checkbox",
        "radio",
        "range",
        "color",
        "date",
        "time",
        "datetime-local",
        "month",
        "week",
        "hidden",
        "button",
        "submit",
        "reset"
      ]);
      if (skip.has(target.type) || target.readOnly || target.disabled) return null;
      return target;
    }
    if (target instanceof HTMLTextAreaElement) {
      if (target.readOnly || target.disabled) return null;
      return target;
    }
    if (target.isContentEditable && target.getAttribute("contenteditable") !== "false") return target;
    return null;
  }
  function textNodes(root) {
    const out = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n = walker.nextNode();
    while (n) {
      out.push(n);
      n = walker.nextNode();
    }
    return out;
  }
  function fieldText(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el.value;
    return textNodes(el).map((n) => n.data).join("");
  }
  function caretOffset(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      return el.selectionStart ?? el.value.length;
    }
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return fieldText(el).length;
    const range = sel.getRangeAt(0);
    let count = 0;
    for (const node of textNodes(el)) {
      if (node === range.endContainer) return count + range.endOffset;
      count += node.data.length;
    }
    return count;
  }
  function insertAtCaret(el, text) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      const start = el.selectionStart ?? el.value.length;
      const end = el.selectionEnd ?? start;
      el.value = el.value.slice(0, start) + text + el.value.slice(end);
      const pos = start + text.length;
      el.setSelectionRange(pos, pos);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) {
      el.append(document.createTextNode(text));
      return;
    }
    const range = sel.getRangeAt(0);
    range.deleteContents();
    const node = document.createTextNode(text);
    range.insertNode(node);
    range.setStartAfter(node);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
  }
  function deleteAtCaret(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      const start = el.selectionStart ?? 0;
      const end = el.selectionEnd ?? start;
      if (start !== end) {
        el.value = el.value.slice(0, start) + el.value.slice(end);
        el.setSelectionRange(start, start);
      } else {
        const before2 = el.value.slice(0, start);
        const peeled2 = deleteLastInputUnit(before2);
        if (peeled2 === before2) return false;
        el.value = peeled2 + el.value.slice(start);
        el.setSelectionRange(peeled2.length, peeled2.length);
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return false;
    const range = sel.getRangeAt(0);
    if (!range.collapsed) {
      range.deleteContents();
      return true;
    }
    let node = range.startContainer;
    let offset = range.startOffset;
    if (node.nodeType !== Node.TEXT_NODE) {
      const prev = node.childNodes[offset - 1] ?? null;
      if (!prev) return false;
      if (prev.nodeType === Node.TEXT_NODE) {
        node = prev;
        offset = prev.data.length;
      } else if (prev instanceof HTMLElement) {
        const texts = textNodes(prev);
        const last = texts[texts.length - 1];
        if (!last) return false;
        node = last;
        offset = last.data.length;
      } else {
        return false;
      }
    } else if (offset === 0) {
      const texts = textNodes(el);
      const idx = texts.indexOf(node);
      if (idx <= 0) return false;
      node = texts[idx - 1];
      offset = node.data.length;
    }
    const textNode = node;
    const before = textNode.data.slice(0, offset);
    const peeled = deleteLastInputUnit(before);
    if (peeled === before) return false;
    textNode.data = peeled + textNode.data.slice(offset);
    const next = document.createRange();
    next.setStart(textNode, peeled.length);
    next.collapse(true);
    sel.removeAllRanges();
    sel.addRange(next);
    return true;
  }
  function replaceSpan(el, start, end, text) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      el.value = el.value.slice(0, start) + text + el.value.slice(end);
      const pos = start + text.length;
      el.setSelectionRange(pos, pos);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    let seen = 0;
    for (const node of textNodes(el)) {
      const len = node.data.length;
      if (start >= seen && end <= seen + len) {
        const a = start - seen;
        const b = end - seen;
        node.data = node.data.slice(0, a) + text + node.data.slice(b);
        return true;
      }
      seen += len;
    }
    return false;
  }
  function eventKey(ev) {
    if (ev.code === "Space" || ev.key === " " || ev.key === "Spacebar") return " ";
    if (ev.code === "Backspace" || ev.key === "Backspace") return "Backspace";
    if (ev.key === "Enter") return "Enter";
    return ev.key;
  }
  async function remember(word) {
    try {
      const res = await chrome.runtime.sendMessage({ type: "lookup", word });
      if (!res || res.known) unknown.delete(word);
      else unknown.set(word, res.suggestions ?? []);
    } catch {
    }
  }
  function noteBoundary(el) {
    if (!proofread) return;
    const offset = caretOffset(el);
    const spans = completedWordSpans(fieldText(el).slice(0, offset));
    const last = spans[spans.length - 1];
    if (!last || last.end > offset) return;
    void remember(last.word);
  }
  document.addEventListener(
    "keydown",
    (ev) => {
      if (ev.ctrlKey || ev.metaKey || ev.altKey || ev.isComposing) return;
      const el = editable(ev.target);
      if (!el) return;
      const key = eventKey(ev);
      if (key !== "Backspace" && key !== " " && key !== "Enter" && key.length !== 1) return;
      const res = handleKey(stateFor(el), { key, code: ev.code, shiftKey: ev.shiftKey });
      states.set(el, res.newState);
      if (res.deleteBackward) {
        if (!deleteAtCaret(el)) return;
        ev.preventDefault();
        ev.stopPropagation();
        return;
      }
      if (key === "Enter") {
        noteBoundary(el);
        return;
      }
      if (!res.consumed) return;
      ev.preventDefault();
      ev.stopPropagation();
      if (res.committedText) insertAtCaret(el, res.committedText);
      noteBoundary(el);
    },
    true
  );
  function wordAt(el) {
    const offset = caretOffset(el);
    let found = null;
    for (const span of completedWordSpans(fieldText(el))) {
      if (offset >= span.start && offset <= span.end + 1) found = span;
    }
    return found;
  }
  var menuHost = null;
  function hidePageMenu() {
    menuHost?.remove();
    menuHost = null;
  }
  function showPageMenu(x, y, el, span, suggestions) {
    hidePageMenu();
    menuHost = document.createElement("div");
    menuHost.setAttribute("data-lipi-skip", "");
    const shadow = menuHost.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    .menu { position: fixed; z-index: 2147483647; left: ${x}px; top: ${y}px; min-width: 196px;
      background: #fffcf7; color: #1c1c1c; border: 1px solid #1c1c1c; border-radius: 10px;
      padding: 6px; box-shadow: 0 10px 28px rgba(28,28,28,.16);
      font-family: Palatino, Georgia, serif; }
    .title { font-family: ui-sans-serif, system-ui, sans-serif; font-size: 11px; letter-spacing: .06em;
      text-transform: uppercase; color: #6b675f; padding: 4px 8px; }
    button { display: block; width: 100%; text-align: left; border: 0; background: transparent;
      font: inherit; font-size: 16px; padding: 6px 8px; border-radius: 6px; cursor: pointer; color: #1c1c1c; }
    button:hover { background: #f4f1ea; }
  `;
    const menu = document.createElement("div");
    menu.className = "menu";
    const title = document.createElement("div");
    title.className = "title";
    title.textContent = suggestions.length ? "Suggestions" : "No suggestions";
    menu.append(title);
    const addBtn = (label, run) => {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = label;
      b.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        run();
      });
      menu.append(b);
    };
    for (const suggestion of suggestions) {
      addBtn(suggestion, () => {
        const ok = replaceSpan(el, span.start, span.end, suggestion);
        unknown.delete(span.word);
        hidePageMenu();
        if (!ok) void navigator.clipboard?.writeText(suggestion);
      });
    }
    addBtn("Add to dictionary", () => {
      unknown.delete(span.word);
      void chrome.runtime.sendMessage({ type: "add", word: span.word });
      hidePageMenu();
    });
    addBtn("Ignore", () => {
      unknown.delete(span.word);
      void chrome.runtime.sendMessage({ type: "ignore", word: span.word });
      hidePageMenu();
    });
    shadow.append(style, menu);
    document.documentElement.append(menuHost);
    const rect = menu.getBoundingClientRect();
    if (rect.right > window.innerWidth - 8) menu.style.left = `${Math.max(8, x - rect.width)}px`;
    if (rect.bottom > window.innerHeight - 8) menu.style.top = `${Math.max(8, y - rect.height)}px`;
  }
  document.addEventListener(
    "contextmenu",
    (ev) => {
      if (!proofread) return;
      const el = editable(ev.target);
      if (!el) return;
      const span = wordAt(el);
      if (!span || !unknown.has(span.word)) return;
      ev.preventDefault();
      ev.stopPropagation();
      showPageMenu(ev.clientX, ev.clientY, el, span, unknown.get(span.word) ?? []);
    },
    true
  );
  document.addEventListener("mousedown", (ev) => {
    if (!menuHost) return;
    if (ev.composedPath().includes(menuHost)) return;
    hidePageMenu();
  }, true);
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape") hidePageMenu();
  }, true);
})();
