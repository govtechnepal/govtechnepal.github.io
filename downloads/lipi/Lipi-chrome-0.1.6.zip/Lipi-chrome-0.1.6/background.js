import {
  Dictionary,
  loadSettings,
  ne_NP_default,
  ne_NP_default2,
  saveSettings
} from "./chunks/chunk-EZEORY6B.js";

// apps/chrome/src/background.ts
var dict;
var applied = /* @__PURE__ */ new Set();
function ensure(settings) {
  if (!dict) dict = Dictionary.parse(ne_NP_default, ne_NP_default2);
  for (const word of settings.userWords) {
    if (applied.has(word)) continue;
    dict.addUserWord(word);
    applied.add(word);
  }
  return dict;
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  void (async () => {
    try {
      const settings = await loadSettings();
      const word = typeof msg?.word === "string" ? msg.word : "";
      if (msg?.type === "lookup") {
        const d = ensure(settings);
        const ignored = settings.ignoredWords.includes(word);
        const known = !word || ignored || d.isKnown(word);
        sendResponse({ known, suggestions: known ? [] : d.corrections(word, 5) });
        return;
      }
      if (msg?.type === "add" && word) {
        if (!settings.userWords.includes(word)) {
          settings.userWords = [...settings.userWords, word];
          await saveSettings(settings);
        }
        ensure(settings).addUserWord(word);
        applied.add(word);
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "ignore" && word) {
        if (!settings.ignoredWords.includes(word)) {
          settings.ignoredWords = [...settings.ignoredWords, word];
          await saveSettings(settings);
        }
        sendResponse({ ok: true });
        return;
      }
      sendResponse({ ok: false });
    } catch (err) {
      sendResponse({ ok: false, error: String(err) });
    }
  })();
  return true;
});
