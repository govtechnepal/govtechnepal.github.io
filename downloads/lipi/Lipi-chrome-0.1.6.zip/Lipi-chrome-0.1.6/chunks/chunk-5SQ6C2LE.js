import {
  Dictionary,
  createState,
  deleteLastInputUnit,
  handleKey,
  loadSettings,
  misspellings,
  ne_NP_default,
  ne_NP_default2,
  onSettingsChanged,
  patchSettings,
  setMode
} from "./chunk-EZEORY6B.js";

// apps/shared/try-field.ts
function speechCtor() {
  const w = window;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}
function mountTryField(root, host) {
  root.innerHTML = `
    <div class="try">
      <div class="try-label" id="try-label">Try this layout</div>
      <div id="try-editor" class="try-editor" contenteditable="true" spellcheck="false" role="textbox" aria-multiline="true" aria-labelledby="try-label" data-placeholder="Type here. Each key writes immediately."></div>
      <div class="try-keys">
        <button type="button" data-try="space">Space</button>
        <button type="button" data-try="backspace">Backspace</button>
        <button type="button" data-try="mic" aria-pressed="false">Mic</button>
        <button type="button" data-try="copy">Copy</button>
      </div>
      <div class="status" data-status></div>
      <div class="menu" hidden data-menu></div>
    </div>
  `;
  const editor = root.querySelector("#try-editor");
  const status = root.querySelector("[data-status]");
  const menu = root.querySelector("[data-menu]");
  const micBtn = root.querySelector('[data-try="mic"]');
  const copyBtn = root.querySelector('[data-try="copy"]');
  if (!host.showCopy) copyBtn.hidden = true;
  let typed = "";
  let ime = createState(host.layout());
  let dict2;
  let recognition = null;
  let listening = false;
  let triedHindi = false;
  function setStatus(text) {
    status.textContent = text;
  }
  function dictIf() {
    if (!host.proofread()) return void 0;
    if (!dict2) {
      dict2 = host.loadDict();
      for (const word of host.userWords()) dict2.addUserWord(word);
    }
    return dict2;
  }
  function hideMenu() {
    menu.hidden = true;
    menu.replaceChildren();
  }
  function placeCaretEnd() {
    const sel = window.getSelection();
    if (!sel) return;
    const range = document.createRange();
    range.selectNodeContents(editor);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
  }
  function renderText() {
    const active = dictIf();
    const ignored = new Set(host.ignoredWords());
    const spans = active ? misspellings(typed, active, ignored) : [];
    const frag = document.createDocumentFragment();
    let cursor = 0;
    for (const span of spans) {
      if (span.start > cursor) frag.append(document.createTextNode(typed.slice(cursor, span.start)));
      const mark = document.createElement("span");
      mark.className = "misspell";
      mark.dataset.word = span.word;
      mark.dataset.start = String(span.start);
      mark.dataset.end = String(span.end);
      mark.textContent = span.word;
      frag.append(mark);
      cursor = span.end;
    }
    if (cursor < typed.length) frag.append(document.createTextNode(typed.slice(cursor)));
    editor.replaceChildren(frag);
    if (document.activeElement === editor) placeCaretEnd();
  }
  function syncLayout() {
    const next = host.layout();
    if (ime.mode !== next) ime = setMode(ime, next);
  }
  function applyKey(key) {
    syncLayout();
    hideMenu();
    if (key === "Enter") {
      const res2 = handleKey(ime, { key: "Enter" }, dictIf());
      ime = res2.newState;
      typed += "\n";
      renderText();
      return;
    }
    const res = handleKey(ime, { key }, dictIf());
    ime = res.newState;
    if (res.deleteBackward) typed = deleteLastInputUnit(typed);
    else if (res.committedText) typed += res.committedText;
    renderText();
  }
  function onKeyDown(ev) {
    if (ev.ctrlKey || ev.metaKey || ev.altKey || ev.isComposing) return;
    const key = ev.code === "Space" || ev.key === " " || ev.key === "Spacebar" ? " " : ev.code === "Backspace" || ev.key === "Backspace" ? "Backspace" : ev.key;
    if (key === "Enter" || key === "Backspace" || key === " " || key.length === 1 && key !== "Unidentified") {
      ev.preventDefault();
      applyKey(key === "Enter" ? "Enter" : key);
    }
  }
  function menuButton(label, onClick) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "menu-item";
    button.textContent = label;
    button.addEventListener("click", onClick);
    return button;
  }
  function showMenu(x, y, word, start, end) {
    const active = dictIf();
    if (!active) return;
    const suggestions = active.corrections(word, 5);
    menu.replaceChildren();
    const title = document.createElement("div");
    title.className = "menu-title";
    title.textContent = suggestions.length ? "Suggestions" : "No suggestions";
    menu.append(title);
    for (const suggestion of suggestions) {
      menu.append(
        menuButton(suggestion, () => {
          typed = typed.slice(0, start) + suggestion + typed.slice(end);
          hideMenu();
          renderText();
          editor.focus();
        })
      );
    }
    menu.append(
      menuButton("Add to dictionary", () => {
        active.addUserWord(word);
        const words = host.userWords().includes(word) ? host.userWords() : [...host.userWords(), word];
        host.onWordsChange(words, host.ignoredWords());
        hideMenu();
        renderText();
      })
    );
    menu.append(
      menuButton("Ignore", () => {
        const ignored = host.ignoredWords().includes(word) ? host.ignoredWords() : [...host.ignoredWords(), word];
        host.onWordsChange(host.userWords(), ignored);
        hideMenu();
        renderText();
      })
    );
    menu.hidden = false;
    menu.style.left = `${x}px`;
    menu.style.top = `${y}px`;
    requestAnimationFrame(() => {
      const rect = menu.getBoundingClientRect();
      if (rect.right > window.innerWidth - 8) menu.style.left = `${Math.max(8, x - rect.width)}px`;
      if (rect.bottom > window.innerHeight - 8) menu.style.top = `${Math.max(8, y - rect.height)}px`;
    });
  }
  function updateMic() {
    micBtn.classList.toggle("on", listening);
    micBtn.setAttribute("aria-pressed", listening ? "true" : "false");
    micBtn.textContent = listening ? "Stop" : "Mic";
  }
  function listen(lang) {
    const Ctor = speechCtor();
    if (!Ctor) {
      setStatus("Voice typing is not available in this view. Use Chrome and allow the microphone when asked.");
      return;
    }
    recognition?.stop();
    const rec = new Ctor();
    recognition = rec;
    rec.lang = lang;
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (ev) => {
      const said = ev.results?.[0]?.[0]?.transcript ?? "";
      if (!said) return;
      typed += said;
      setStatus("");
      renderText();
      editor.focus();
    };
    rec.onerror = (ev) => {
      const code = ev.error ?? "";
      if (!triedHindi && (code === "language-not-supported" || code === "language-unavailable")) {
        triedHindi = true;
        setStatus("Nepali speech is unavailable here. Trying Hindi.");
        listen("hi-IN");
        return;
      }
      listening = false;
      updateMic();
      if (code === "not-allowed" || code === "service-not-allowed") {
        setStatus("Microphone permission was blocked. Allow the mic for Lipi and press Mic again.");
        return;
      }
      if (code === "aborted" || code === "no-speech") {
        if (code === "no-speech") setStatus("No speech heard. Press Mic and try again.");
        return;
      }
      setStatus("Voice typing is not available here. Use Chrome and allow the microphone.");
    };
    rec.onend = () => {
      listening = false;
      updateMic();
    };
    try {
      rec.start();
      listening = true;
      updateMic();
      setStatus(lang === "hi-IN" ? "Listening (Hindi)\u2026" : "Listening (Nepali)\u2026");
    } catch {
      listening = false;
      updateMic();
      setStatus("Voice typing is not available here. Use Chrome and allow the microphone.");
    }
  }
  editor.addEventListener("keydown", onKeyDown);
  editor.addEventListener("paste", (ev) => {
    ev.preventDefault();
    const text = ev.clipboardData?.getData("text/plain") ?? "";
    if (!text) return;
    typed += text;
    renderText();
    placeCaretEnd();
  });
  editor.addEventListener("contextmenu", (ev) => {
    const target = ev.target;
    if (!(target instanceof Element)) return;
    const mark = target.closest(".misspell");
    if (!mark || !host.proofread()) return;
    ev.preventDefault();
    showMenu(
      ev.clientX,
      ev.clientY,
      mark.dataset.word ?? "",
      Number(mark.dataset.start ?? "0"),
      Number(mark.dataset.end ?? "0")
    );
  });
  const onPointerDown = (ev) => {
    if (menu.hidden) return;
    if (ev.target instanceof Node && menu.contains(ev.target)) return;
    hideMenu();
  };
  const onEscape = (ev) => {
    if (ev.key === "Escape") hideMenu();
  };
  document.addEventListener("mousedown", onPointerDown);
  document.addEventListener("keydown", onEscape);
  root.querySelector('[data-try="space"]')?.addEventListener("click", () => {
    applyKey(" ");
    editor.focus();
  });
  root.querySelector('[data-try="backspace"]')?.addEventListener("click", () => {
    applyKey("Backspace");
    editor.focus();
  });
  micBtn.addEventListener("click", () => {
    if (listening) {
      recognition?.stop();
      listening = false;
      updateMic();
      setStatus("");
      return;
    }
    triedHindi = false;
    listen("ne-NP");
  });
  copyBtn.addEventListener("click", async () => {
    const ok = await copyPlain(typed);
    setStatus(ok ? "Copied." : "Could not copy. Select the text and copy it yourself.");
  });
  return {
    refresh: () => {
      syncLayout();
      renderText();
    },
    getText: () => typed
  };
}
async function copyPlain(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.left = "-9999px";
      document.body.append(area);
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

// apps/chrome/src/shell.ts
function chromeApi() {
  return globalThis.chrome ?? {};
}
var dict;
function loadDict() {
  if (!dict) dict = Dictionary.parse(ne_NP_default, ne_NP_default2);
  return dict;
}
async function mountChromeApp(root, mode) {
  document.body.dataset.mode = mode;
  let config = await loadSettings();
  let tryField = null;
  const pageNote = mode === "page" ? "This page is the reliable place to type. Keys commit immediately. Copy when you are done. If a website fights with Lipi, type here instead." : "Lipi also types into text fields on the page. If a site fights with that, use this box or the typing page.";
  root.innerHTML = `
    <h1>Lipi</h1>
    <p class="tagline">Type Nepali</p>
    <div class="layouts">
      <button type="button" class="layout" data-layout="romanized">
        <strong>Romanized</strong>
        <span>k is \u0915, a is \u093E.</span>
      </button>
      <button type="button" class="layout" data-layout="traditional">
        <strong>Traditional</strong>
        <span>s is \u0915, f is \u093E.</span>
      </button>
    </div>
    <div class="text-actions">
      <button type="button" id="open-side">Side panel</button>
      <button type="button" id="open-page">Typing page</button>
    </div>
    <div class="steps">
      <h2>In the browser</h2>
      <ol>
        <li>${pageNote}</li>
        <li>Backspace after \u0943, \u093E, \u093F, or \u094D leaves the consonant.</li>
        <li>Proofread stays off until you turn it on. Right-click an underline. The mic asks for permission.</li>
      </ol>
    </div>
    <label class="option">
      <input type="checkbox" id="corr" />
      <span>Underline words that are not in the Nepali dictionary after a space or punctuation. Right-click an underline for suggestions, Add to dictionary, or Ignore. Off unless you turn it on. No suggestion bar while you type.</span>
    </label>
    <div id="try-root"></div>
    <p class="foot">Hunspell ne_NP is LGPL-2.1. See CREDITS.md. Voice uses ne-NP, then hi-IN. Allow the microphone when Chrome asks.</p>
  `;
  if (mode === "page") {
    const side = document.getElementById("open-side");
    const page = document.getElementById("open-page");
    side?.remove();
    page?.remove();
    if (!root.querySelector(".text-actions button")) {
      root.querySelector(".text-actions")?.remove();
    }
  }
  if (mode === "sidepanel") document.getElementById("open-side")?.remove();
  function paint() {
    for (const btn of root.querySelectorAll("[data-layout]")) {
      btn.classList.toggle("selected", btn.dataset.layout === config.layout);
    }
    const corr2 = document.getElementById("corr");
    if (corr2) corr2.checked = config.suggestCorrections;
    tryField?.refresh();
  }
  async function choose(layout) {
    config = await patchSettings({ layout, firstRunComplete: true });
    paint();
  }
  root.querySelectorAll("[data-layout]").forEach((btn) => {
    btn.addEventListener("click", () => void choose(btn.dataset.layout));
  });
  const corr = document.getElementById("corr");
  corr?.addEventListener("change", () => {
    void patchSettings({ suggestCorrections: corr.checked }).then((next) => {
      config = next;
      paint();
    });
  });
  document.getElementById("open-page")?.addEventListener("click", () => {
    const c = chromeApi();
    const url = c.runtime?.getURL?.("type.html") ?? "type.html";
    if (c.tabs?.create) void c.tabs.create({ url });
    else window.open(url, "_blank");
  });
  document.getElementById("open-side")?.addEventListener("click", () => {
    void (async () => {
      const c = chromeApi();
      try {
        const win = await c.windows?.getCurrent?.();
        if (win?.id != null && c.sidePanel?.open) {
          await c.sidePanel.open({ windowId: win.id });
          return;
        }
      } catch {
      }
      const url = c.runtime?.getURL?.("type.html") ?? "type.html";
      if (c.tabs?.create) void c.tabs.create({ url });
      else window.open(url, "_blank");
    })();
  });
  tryField = mountTryField(document.getElementById("try-root"), {
    layout: () => config.layout,
    proofread: () => config.suggestCorrections,
    userWords: () => config.userWords,
    ignoredWords: () => config.ignoredWords,
    showCopy: true,
    loadDict,
    onWordsChange: (userWords, ignoredWords) => {
      config = { ...config, userWords, ignoredWords };
      void patchSettings({ userWords, ignoredWords }).then((next) => {
        config = next;
      });
    }
  });
  paint();
  onSettingsChanged(() => {
    void loadSettings().then((next) => {
      config = next;
      paint();
    });
  });
}

export {
  mountChromeApp
};
