# Lipi — Type Nepali (Chrome)

Version 0.1.6. Romanized and Traditional. Keys commit immediately. No suggestion bar.

The extension types into text fields when it can. If a site fights with that, use the typing page and Copy.

## Load unpacked

1. Unzip `Lipi-chrome-0.1.6.zip`.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and choose the unzipped folder (the one that contains `manifest.json`).
5. Pin Lipi. The popup and the side panel switch layouts, hold the try field, and hold the proofread switch. Proofread is **off** until you turn it on.

## Microphone

Press **Mic** in the popup, side panel, or typing page. Chrome asks for the microphone. Allow it.

Speech uses Nepali (`ne-NP`). If that language is unavailable, Lipi tries Hindi (`hi-IN`). If this Chrome has no Web Speech API, Lipi says so instead of failing quietly.

## Proofread

After a space or punctuation, a word that is not in the Nepali Hunspell dictionary (`ne_NP`, LGPL-2.1) gets a light underline in the Lipi try field. Right-click it for suggestions, **Add to dictionary**, or **Ignore**.

On ordinary web fields there is no underline. After you finish a word, right-click that word for the same menu when proofread is on.

Nothing suggests words while you are still typing.
